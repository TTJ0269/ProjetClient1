<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Entreprise extends Model
{
    use HasFactory;
    protected $guarded = [];


    //Pour recuperer les clients qui appartient a l'entreprise
    public function clients()
    {
        return $this->hasMany('App\Models\Client');
    }
}
