<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;

    //perciser les champs à remplir
   // protected $fillable = ['name','email','status'];
    protected $guarded = [];

    protected $attributes=[
        'status'=> 0
    ];

    public function scopeStatus($query)
    {
        return $query->where('status','=',1)->get();
    }

    public function entreprise()
    {
        return $this->belongsTo('App\Models\Entreprise');
    }

    public function getStatusAttribute($attributes)
    {
     
         return $this->getStatusOptions()[$attributes];
    }
    
    public function getStatusOptions()
    {
        return [
            '0' => 'Inactif',
            '1' => 'Actif'
        ];
    }
}

