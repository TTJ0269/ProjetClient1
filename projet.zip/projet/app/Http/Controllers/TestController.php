<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Entreprise;

class TestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   // Afficher les clients
    public function index()
    {
        
        $clients = Client::all();

        return view('clients.index', compact('clients'));
 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $entreprises= Entreprise::all();
        $client = new Client();

        return view('clients.create',compact('entreprises','client'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {   
        $client = Client::create($this->validator());
        //return back();

        $this->storeImage($client);
        return redirect('clients')->with('message', 'Client bien ajouté.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Client $client)
    {
        //$client = Client::where('id',$client)->firstOrfail(); recuperer le client a id passé c'est la même chose avant Client $client

        return view('clients.show', compact('client'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Client $client)
    {
        $entreprises = Entreprise::all();

        return view('clients.edit', compact('client', 'entreprises'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Client $client)
    {
        $client->update($this->validator());

        return redirect('clients/' . $client->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Client $client)
    {
        $client->delete();

        return redirect('clients');
    }

    private  function validator()
    {
        return request()->validate([
            'name'=>'required|min:3',
            'email'=>'required|email',
            'status'=>'required|integer',
            'entreprise_id'=>'required|integer',
            'image'=>'required|image|max:5000'
        ]);   
    }

    private function storeImage(Client $client)
    {
         if(request('image'))
         {
             $client->update([
              'image'=> request('image')->store('avatars','public'),
             ]);       
         }
    }
}
