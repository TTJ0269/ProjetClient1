<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Entreprise;
use Illuminate\Http\Request;

class ClientsController extends Controller
{
    public function list()
    {
        //$clients = Client::all();
        //$clients = Client::where('status','=',1)->get();
        $clients = Client::status();
        $entreprises= Entreprise::all();

        return view('clients.index', compact('clients','entreprises'));
    }

    public function Store()
    {
       $data = request()->validate([
            'name'=>'required|min:3',
            'email'=>'required|email',
            'status'=>'required|integer',
            'entreprise_id'=>'required|integer'
        ]);      
        Client::create($data);
        return back();
       
        /* **c'est la même chose avec  Client::create($data);**
        $pseudo = request('name');
        $email = request('email');
        $status = request('status');

        $client = new Client();
        $client->name = $name;
        $client->email = $email;
        $client->status = $status;
        $client->save();*/

     
    } 
}

