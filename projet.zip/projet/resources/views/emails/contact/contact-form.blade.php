@component('mail::message')
# Salut

Vous avez reçu un mail de la part de {{ $data['name'] }} ({{ $data['email'] }})

Message
{{ $data['message']}}

@component('mail::button', ['url' => ''])
Bouton Text
@endcomponent

Merci,<br>
{{ config('app.name') }}
@endcomponent
