@extends('layouts.app')

@section('content')

<h1>A propos</h1>
<p>vous allez encore aux cours ?</p>

@endsection