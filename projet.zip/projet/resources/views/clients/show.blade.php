@extends('layouts.app')

@section('content')

<h1> {{ $client->name }}</h1>
<a href="/clients/{{ $client->id }}/edit" class="btn btn-secondary my-3">Modifier</a>
<form action="/clients/{{ $client->id }}" method="POST" style="display: inline;">
 @csrf
 @method('DELETE')
 <button type="submit" class="btn btn-danger">Supprimer</button>
 </form>
<hr>
<p><strong>Email :</strong> {{$client->email}}</p>
<p><strong>Entreprise :</strong> {{$client->entreprise->name}}</p>
@if($client->image)
<img src="{{ asset('storage/' .$client->image) }}" alt="clients-avatars" class="img-thumbnail" width="400">
@endif
@endsection