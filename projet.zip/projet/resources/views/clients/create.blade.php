@extends('layouts.app')

@section('content')

<h1>Créer un nouveau client</h1>
<form action="/clients" method="POST" enctype="multipart/form-data">
  @include('includes.form')
    <button type="submit" class="btn btn-primary my-3">Ajouter le client</button>
</form>

@endsection