@extends('layouts.app')

@section('content')

<h1>Modifier le profil de {{ $client->name }}</h1>
<form action="/clients/{{ $client->id }}" method="POST" enctype="multipart/form-data">
  @method('PATCH')
  @include('includes.form')
    <button type="submit" class="btn btn-primary my-3">Sauvegarder les informations</button>
</form>

@endsection