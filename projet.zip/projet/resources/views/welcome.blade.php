@extends('layouts.app')

@section('content')

<h1>Apprendre Laravel</h1>
@endsection