<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Models\Client;
use App\Models\Entreprise;
use App\Http\Controllers\TestController;
use App\Http\Controllers\ContactContoller;
Route::view('/', 'Welcome');

Route::view('/a-propos', 'a-propos');

Route::resource('/clients','TestController');

Route::get('/contact', 'ContactController@create');
Route::post('/contact', 'ContactController@store');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


//Route::get('clients', 'TestController@index');
//Route::get('clients', function() {});



//Route::post("\afficher","TestController@test");
//Route::get('/clients/create', 'TestController@create');
//Route::post('/clients', 'TestController@store');
//Route::get('/clients/{client}', 'TestController@show');
