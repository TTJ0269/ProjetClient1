<?php $__env->startSection('content'); ?>

<h1>Contactez-nous</h1>
<em>TTJ</em>
<p>90597473</p>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\projet\resources\views/contact.blade.php ENDPATH**/ ?>