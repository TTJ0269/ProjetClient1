<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel\projet\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>