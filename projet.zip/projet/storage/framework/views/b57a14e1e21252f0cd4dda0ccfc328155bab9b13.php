<h1>Client</h1>

<ul>
<?php $__currentLoopData = $clt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($client); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\laravel\projet\resources\views/client/index.blade.php ENDPATH**/ ?>